from django.contrib import admin
from .models import RegisterUser,Follow

admin.site.register(RegisterUser)
admin.site.register(Follow)